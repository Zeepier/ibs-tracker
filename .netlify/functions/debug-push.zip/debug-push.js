// Diagnostic endpoint — remove after debugging
// GET /.netlify/functions/debug-push        → lists all sub:* keys in Upstash
// GET /.netlify/functions/debug-push?write=1 → writes a dummy key then reads it back

async function redis(method, ...args) {
  const url = `${process.env.UPSTASH_REDIS_REST_URL}/${[method, ...args].map(encodeURIComponent).join('/')}`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${process.env.UPSTASH_REDIS_REST_TOKEN}` },
  });
  const text = await res.text();
  return { status: res.status, body: text };
}

exports.handler = async (event) => {
  const write = event?.queryStringParameters?.write === '1';
  const results = {};

  // Check env vars are present (don't log values)
  results.envVars = {
    UPSTASH_REDIS_REST_URL: !!process.env.UPSTASH_REDIS_REST_URL,
    UPSTASH_REDIS_REST_TOKEN: !!process.env.UPSTASH_REDIS_REST_TOKEN,
    VAPID_PUBLIC_KEY: !!process.env.VAPID_PUBLIC_KEY,
    VAPID_PRIVATE_KEY: !!process.env.VAPID_PRIVATE_KEY,
  };

  if (write) {
    // Write a test value
    results.write = await redis('SET', 'debug:test', 'hello');
    // Read it back
    results.read = await redis('GET', 'debug:test');
    // Clean up
    results.del = await redis('DEL', 'debug:test');
  }

  // List all subscription keys
  results.keys = await redis('KEYS', 'sub:*');

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(results, null, 2),
  };
};
